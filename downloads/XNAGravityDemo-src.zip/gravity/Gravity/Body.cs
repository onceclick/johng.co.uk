using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Gravity.Sprite;

namespace Gravity
{
    class Body
    {
        private float mFRot;
        public float fRot
        {
            get
            {
                return mFRot;
            }
            set
            {
                mFRot = value;
                updateArea = true;
            }
        }
        private Texture2D mBodyTexture;
        public Texture2D BodyTexture
        {
            get
            {
                return mBodyTexture;
            }
            set
            {
                mBodyTexture = value;
            }
        }
        private Sprite.Sprite mBody;
        public Sprite.Sprite SpriteBody
        {
            get
            {
                return mBody;
            }
            set
            {
                mBody = value;
            }
        }
        private double xVelo;
        public double xV
        {
            get
            {
                return xVelo;
            }
            set
            {
                xVelo = value;
            }
        }
        private double yVelo;
        public double yV
        {
            get
            {
                return yVelo;
            }
            set
            {
                yVelo = value;
            }
        }
        public int xPosition
        {
            get
            {
                return (int)mBody.Position.X;
            }
        }
        public int yPosition
        {
            get
            {
                return (int)mBody.Position.Y;
            }
        }
        private double mMass;
        public double Mass
        {
            get
            {
                return mMass;
            }
            set
            {
                mMass = value;
            }
        }
        private float screenWidth;
        private float screenHeight;

        private BoundingSphere mBoundingSphere;
        public BoundingSphere boundingSphere
        {
            get
            {
                return mBoundingSphere;
            }
            set
            {
                mBoundingSphere = value;
            }
        }
        public Vector3 boundingSphereCenter
        {
            get
            {
                return mBoundingSphere.Center;
            }
            set
            {
                mBoundingSphere.Center = value;
            }
        }
        public float boundingSphereRadius
        {
            get
            {
                return mBoundingSphere.Radius;
            }
            set
            {
                mBoundingSphere.Radius = value;
            }
        }
        private bool updateArea = true;
        private int minX, minY;
        private int maxX, maxY;
        private Dictionary<Point, bool> areaTransformed;

        public Body(GraphicsDevice theDevice, ContentManager theLoader)
        {
            screenWidth = theDevice.Viewport.Width;
            screenHeight = theDevice.Viewport.Height;
        }

        private List<Point> hull;

        public void CalcArea()
        {
            Console.WriteLine(mBody.TextureWidth);
            Console.WriteLine(mBody.TextureHeight);
            uint[] bits = new uint[mBody.TextureWidth * mBody.TextureHeight];
            mBodyTexture.GetData<uint>(bits);

            hull = new List<Point>();

            for (int x = 0; x < mBody.TextureWidth; x++)
            {
                for (int y = 0; y < mBody.TextureHeight; y++)
                {
                    if ((bits[x + y * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                        continue;


                    bool bSilouette = false;

                    //check for an alpha next to a color to make sure this is an edge
                    //right
                    if (x < mBodyTexture.Width - 1)
                    {
                        if ((bits[x + 1 + y * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }
                    //left
                    if (!bSilouette && x > 0)
                    {
                        if ((bits[x - 1 + y * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }
                    //top
                    if (!bSilouette && y > 0)
                    {
                        if ((bits[x + (y - 1) * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }
                    //bottom
                    if (!bSilouette && y < mBody.TextureHeight - 1)
                    {
                        if ((bits[x + (y + 1) * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }
                    //bottom left
                    if (!bSilouette && x > 0 && y < mBody.TextureHeight - 1)
                    {
                        if ((bits[x - 1 + (y + 1) * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }
                    //bottom right
                    if (!bSilouette && x < mBody.TextureWidth - 1 && y < mBody.TextureHeight - 1)
                    {
                        if ((bits[x + 1 + (y + 1) * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }
                    //top left
                    if (!bSilouette && x > 0 && y > 0)
                    {
                        if ((bits[x - 1 + (y - 1) * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }
                    //top right
                    if (!bSilouette && x < mBody.TextureWidth && y > 0)
                    {
                        if ((bits[x + 1 + (y - 1) * mBody.TextureWidth] & 0xFF000000) >> 24 <= 20)
                            bSilouette = true;
                    }

                    Point p = new Point(x, y);
                    if (bSilouette && !hull.Contains(p))
                        hull.Add(p);
                }
            }
        }

        public static bool Intersects(Body a, Body b)
        {
            if (!a.boundingSphere.Intersects(b.boundingSphere))
                return false;

            if (a.updateArea)
                a.UpdateArea();

            if (b.updateArea)
                b.UpdateArea();

            int minX1 = a.minX + (int)a.mBody.Position.X;
            int maxX1 = a.maxX + (int)a.mBody.Position.X;
            int minY1 = a.minY + (int)a.mBody.Position.Y;
            int maxY1 = a.maxY + (int)a.mBody.Position.Y;

            int minX2 = b.minX + (int)a.mBody.Position.X;
            int maxX2 = b.maxX + (int)a.mBody.Position.X;
            int minY2 = b.minY + (int)a.mBody.Position.Y;
            int maxY2 = b.maxY + (int)a.mBody.Position.Y;

            if (maxX1 < minX2 || minX1 > maxX2 ||
                maxY1 < minY2 || minY1 > maxY2)
                return false;

            Dictionary<Point, bool>.Enumerator enumer = a.areaTransformed.GetEnumerator();
            while (enumer.MoveNext())
            {
                Point point1 = enumer.Current.Key;
                int x1 = point1.X + (int)a.mBody.Position.X;
                int y1 = point1.Y + (int)a.mBody.Position.Y;

                if (x1 < minX2 || x1 > maxX2 ||
                    y1 < minY2 || y1 > maxY2)
                    continue;

                if (b.areaTransformed.ContainsKey(new Point(x1 - (int)a.mBody.Position.X, y1 - (int)a.mBody.Position.Y)))
                    return true;
            }
            return false;
        }

        public void UpdateArea()
        {

            areaTransformed = new Dictionary<Point, bool>(areaTransformed == null ? 0 : areaTransformed.Count);

            minX = mBodyTexture.Width;
            minY = mBodyTexture.Height;
            maxX = -mBodyTexture.Width;
            maxY = -mBodyTexture.Height;

            int centerX = mBodyTexture.Width / 2;
            int centerY = minY = mBodyTexture.Height / 2;

            float cos = (float)Math.Cos(fRot);
            float sin = (float)Math.Sin(fRot);

            foreach (Point p in hull)
            {
                int newX = (int)Math.Round((p.X - centerX) * cos - (p.Y - centerY) * sin);
                int newY = (int)Math.Round((p.Y - centerY) * cos + (p.X - centerX) * sin);

                if (minX > newX) minX = newX;
                if (minY > newY) minY = newY;
                if (maxX < newX) maxX = newX;
                if (maxY < newY) maxY = newY;

                Point newP = new Point(newX, newY);
                if (!areaTransformed.ContainsKey(newP))
                {
                    areaTransformed.Add(newP, true);
                }

            }

            updateArea = false;
        }



        public void Draw(SpriteBatch theSpriteBatch)
        {
            theSpriteBatch.Draw(mBodyTexture, mBody.Destination, mBody.Source, Color.White,
                fRot, new Vector2(mBody.Width / 2, mBody.Height / 2), SpriteEffects.None, 0);
        }

        public virtual void Update(double xAccel, double yAccel)
        {
            UpdatePosition(xAccel, yAccel);
        }

        public void UpdatePosition(double xAccel, double yAccel)
        {
            xVelo += xAccel;
            yVelo += yAccel;
            float newXC = mBody.Position.X - (float)xVelo;
            float newYC = mBody.Position.Y - (float)yVelo;
            if (newXC < 0)
            {
                newXC = 0;
            }
            else if (newXC > screenWidth)
            {
                newXC = screenWidth;
            }

            if (newYC < 0)
            {
                newYC = 0;
            }
            if (newYC > screenHeight)
            {
                newYC = screenHeight;
            }
            mBody.Position = new Vector2(newXC, newYC);
            boundingSphereCenter = new Vector3(newXC, newYC, 0);
        }
    }
}