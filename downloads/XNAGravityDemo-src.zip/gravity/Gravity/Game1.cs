
#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion

namespace Gravity
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        ContentManager content;
        SpriteBatch mSpriteBatch;
        Planet mPlanet;
        //Asteroid mAsteroid;
        List<Body> bodies;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            content = new ContentManager(Services);
            this.graphics.PreferredBackBufferWidth = 1280;
            this.graphics.PreferredBackBufferHeight = 720;
        }


        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            mSpriteBatch = new SpriteBatch(this.graphics.GraphicsDevice);
            ContentManager aLoader = new ContentManager(Services);
            bodies = new List<Body>();
            mPlanet = new Planet(this.graphics.GraphicsDevice, aLoader);
            //mAsteroid = new Asteroid(this.graphics.GraphicsDevice, aLoader);
            
            bodies.Add(new Asteroid(this.graphics.GraphicsDevice, aLoader));
            bodies.Add(new Ship(this.graphics.GraphicsDevice, aLoader));
            base.Initialize();
        }


        /// <summary>
        /// Load your graphics content.  If loadAllContent is true, you should
        /// load content from both ResourceManagementMode pools.  Otherwise, just
        /// load ResourceManagementMode.Manual content.
        /// </summary>
        /// <param name="loadAllContent">Which type of content to load.</param>
        protected override void LoadGraphicsContent(bool loadAllContent)
        {
            if (loadAllContent)
            {
                // TODO: Load any ResourceManagementMode.Automatic content
            }

            // TODO: Load any ResourceManagementMode.Manual content
        }


        /// <summary>
        /// Unload your graphics content.  If unloadAllContent is true, you should
        /// unload content from both ResourceManagementMode pools.  Otherwise, just
        /// unload ResourceManagementMode.Manual content.  Manual content will get
        /// Disposed by the GraphicsDevice during a Reset.
        /// </summary>
        /// <param name="unloadAllContent">Which type of content to unload.</param>
        protected override void UnloadGraphicsContent(bool unloadAllContent)
        {
            if (unloadAllContent == true)
            {
                content.Unload();
            }
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the default game to exit on Xbox 360 and Windows
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            UpdateGravity();


            // COLLISION DETECTION
            /* 
             * 
             * 
             */


            if (Body.Intersects(bodies[0], bodies[1]))
            {
                Console.WriteLine("COLLISION");
                double masses = ((bodies[0].Mass - bodies[1].Mass) / (bodies[0].Mass + bodies[1].Mass));
                double v1x = masses * bodies[0].xV;
                double v1y = masses * bodies[0].yV;

                double masses2 = (2 * bodies[0].Mass) / (bodies[0].Mass + bodies[1].Mass);
                double v2x = masses2 * bodies[0].xV;
                double v2y = masses2 * bodies[0].yV;

                bodies[0].xV = v1x;
                bodies[0].yV = v1y;
                bodies[1].xV = v2x;
                bodies[1].yV = v2y;
            }
            else
            {
                Console.WriteLine("NO");
            }

            base.Update(gameTime);
        }

        protected void UpdateGravity()
        {
            foreach (Body aBody in bodies)
            {
                double xd = aBody.xPosition - mPlanet.xPosition;
                double yd = aBody.yPosition - mPlanet.yPosition;
                double dist = Math.Sqrt((xd * xd) + (yd * yd));
                if (dist < mPlanet.Width)
                {
                    dist = mPlanet.Width;
                }

                double grav = ((aBody.Mass * mPlanet.Mass) / (dist * dist)) * 5;

                double xGrav = grav * (xd / dist);
                double yGrav = grav * (yd / dist);
                double xAccel = xGrav / aBody.Mass;
                double yAccel = yGrav / aBody.Mass;

                aBody.Update(xAccel, yAccel);
            }
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Black);

            mSpriteBatch.Begin(SpriteBlendMode.AlphaBlend);
            mPlanet.Draw(mSpriteBatch);
            foreach (Body aBody in bodies)
            {
                aBody.Draw(mSpriteBatch);
            }
            mSpriteBatch.End();

            base.Draw(gameTime);
        }
    }
}