using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace Gravity
{
    class Ship : Gravity.Body
    {
        Sprite.Sprite Blob;

        public Ship(GraphicsDevice theDevice, ContentManager theLoader)
            : base(theDevice, theLoader)
        {
            BodyTexture = theLoader.Load<Texture2D>("ship") as Texture2D;
            SpriteBody = new Sprite.Sprite(new Rectangle(100, 50, 64, 64), new Rectangle(0, 0, 64, 64));
            Blob = new Sprite.Sprite(new Rectangle((int)(SpriteBody.Position.X - (SpriteBody.Width / 2)), (int)(SpriteBody.Position.Y - (SpriteBody.Height / 2)), 19, 18), new Rectangle(384, 61, 19, 18));
            SpriteBody.Visible = true;
            xV = 1;
            yV = 0;
            Mass = SpriteBody.Width;
            fRot = 0.0f;
            boundingSphereCenter = new Vector3(SpriteBody.TextureWidth / 2, SpriteBody.TextureHeight / 2, 0);
            boundingSphereRadius = (float)Math.Sqrt(SpriteBody.TextureWidth * SpriteBody.TextureWidth + SpriteBody.TextureHeight * SpriteBody.TextureHeight) / 2.0f;
            CalcArea();
        }

        public override void Update(double xAccel, double yAccel)
        {
            UpdatePosition(xAccel, yAccel);
            UpdateKeyboard();
        }

        public void UpdateKeyboard()
        {
            float rotationSpeed = 0.05f;
            KeyboardState aKeyboard = Keyboard.GetState();
            if (aKeyboard.IsKeyDown(Keys.Left) == true || GamePad.GetState(PlayerIndex.One).DPad.Left == ButtonState.Pressed)
            {
                fRot -= rotationSpeed;
                if (fRot < 0)
                {
                    fRot = 2 * (float)Math.PI;
                }
            }
            else if (aKeyboard.IsKeyDown(Keys.Right) == true || GamePad.GetState(PlayerIndex.One).DPad.Right == ButtonState.Pressed)
            {
                fRot += rotationSpeed;
                if (fRot > 2 * Math.PI)
                {
                    fRot = 0;
                }
            }
            else if (aKeyboard.IsKeyDown(Keys.Up) == true || GamePad.GetState(PlayerIndex.One).Triggers.Right > 0)
            {
                float xDir = (float)Math.Sin(fRot);
                float yDir = (float)Math.Cos(fRot);
                xV = -xDir*2;
                yV = yDir*2;
                //SpriteBody.Position += new Vector2(xDir, yDir);
            }
            else if (aKeyboard.IsKeyDown(Keys.Down) == true || GamePad.GetState(PlayerIndex.One).Triggers.Left > 0)
            {
                yV = 1;
            }
        }
    }
}