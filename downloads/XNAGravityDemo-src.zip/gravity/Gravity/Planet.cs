using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Gravity.Sprite;

namespace Gravity
{
    class Planet
    {
        Texture2D mPlanetTexture;
        Sprite.Sprite mPlanet;
        public int xPosition
        {
            get
            {
                return (int)mPlanet.Position.X;
            }
        }
        public int yPosition
        {
            get
            {
                return (int)mPlanet.Position.Y;
            }
        }
        private double mMass;
        public double Mass
        {
            get
            {
                return mMass;
            }
            set
            {
                mMass = value;
            }
        }

        public double Width
        {
            get
            {
                return mPlanet.Width;
            }
            set
            {
                mPlanet.Width = (int)value;
            }
        }

        public Planet(GraphicsDevice theDevice, ContentManager theLoader)
        {
            mPlanetTexture = theLoader.Load<Texture2D>("image") as Texture2D;
            mPlanet = new Sprite.Sprite(new Rectangle(theDevice.Viewport.Width/2, theDevice.Viewport.Height/2, 160, 160), new Rectangle(0, 0, 160, 160));
            mPlanet.Visible = true;
            Mass = mPlanet.Width;
        }

        public void Draw(SpriteBatch theSpriteBatch)
        {
            theSpriteBatch.Draw(mPlanetTexture, mPlanet.Destination, mPlanet.Source, Color.White,
                0.0f, new Vector2(mPlanet.Width / 2, mPlanet.Height / 2), SpriteEffects.None, 0);
        }
    }
}
