using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Gravity.Sprite;

namespace Gravity
{
    class Asteroid : Gravity.Body
    {
        public Asteroid(GraphicsDevice theDevice, ContentManager theLoader) : base(theDevice, theLoader)
        {
            BodyTexture = theLoader.Load<Texture2D>("asteroid") as Texture2D;
            SpriteBody = new Sprite.Sprite(new Rectangle(theDevice.Viewport.Width/2, 50, 64, 64), new Rectangle(0, 0, 64, 64));
            SpriteBody.Visible = true;
            xV = 1;
            yV = 0;
            Mass = SpriteBody.Width;
            CalcArea();
        }
    }
}
